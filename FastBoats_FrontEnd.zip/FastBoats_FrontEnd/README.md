# Autor

Pedro Antunes.

## Redes Sociais
[Instagram](https://www.instagram.com/pedro.antunes1/)<br>
[LinkedIn](https://www.linkedin.com/in/pedro-antunes-250187215/)<br>
[Site do Projeto]()


### Descrição Sobre o Projeto
A Tematica do site será Nautico. Pensando em disponibilizar um serviço de qualidade, criamos o nosso site nautico que nele você poderá anunciar seu barco/jetski e vender.

### Explicando sobre Pj3
O PJ3 é uma materia do curso, e este projeto é uma das metas a ficar pronto até o final do curso
Utiliza PHP, React, Etc


