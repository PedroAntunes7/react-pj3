import FormContato from "./formcontato";


const UsandoIcons = () => {  
    return (
        <>
      <FormContato />
        </>
    );
  }
  
export default UsandoIcons;