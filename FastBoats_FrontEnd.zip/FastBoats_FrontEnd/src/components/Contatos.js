const Contatos = () => {
    return (
      <>
      kihu
      </>
    
    
    
    
    
    
)}

export default Contatos