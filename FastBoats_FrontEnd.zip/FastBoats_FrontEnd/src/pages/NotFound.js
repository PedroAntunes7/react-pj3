import React from 'react'

const NotFound = () => {
  return (
    <div>404 - Página Não Encontrada!</div>
  )
}

export default NotFound